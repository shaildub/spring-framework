package com.capgemini;

public class Display {

}
