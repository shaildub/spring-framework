package com.capgemini;

public class LoginController {

}
