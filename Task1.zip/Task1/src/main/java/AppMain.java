import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.pojo.Constructor_injection.Employee;

public class AppMain {
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("app-config.xml");
		Employee ee = (Employee)context.getBean("capgemini");
		ee.display();
		
		System.out.println("\n!!! DONE !!!");
	}


}
