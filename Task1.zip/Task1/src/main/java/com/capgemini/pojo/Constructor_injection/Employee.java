package com.capgemini.pojo.Constructor_injection;

public class Employee {
	
	private int empno;
	private String company;
	
//	public Employee(int emp, String com) {
//		this.empno = emp;
//		this.company = com;
//	}
	
	public Employee(int emp) {
		this.empno = emp;
	}
	
	public void setCompany(String company) {
		this.company = company;
	}
	
	public int getEmpno() {
		return empno;
	}
	
	public String getCompany() {
		return company;
	}

	public void display() {
		
		System.out.println("\n---Method Called---\n");
		System.out.println("Emp no.: " + empno);
		System.out.println("Company: " + company);
		
	}
}
