package com.capgemini.pojo.SpringLab5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		TextEditor tx=(TextEditor)context.getBean("textEditor");
		tx.checkSpell();
	}

}
