package com.capgemini.pojo.SpringLab5;

public class TextEditor {

	private SpellChecker spellChecker;
	private String name;

//	byConstructor
	
	public TextEditor(SpellChecker spellChecker, String name) {
		this.spellChecker = spellChecker;
		this.name = name;
	}

//	byName OR byType
	
	public SpellChecker getSpellChecker() {
		return spellChecker;
	}
	
//	public void setSpellChecker(SpellChecker spellChecker) {
//		this.spellChecker = spellChecker;
//	}
	
	public String getName() {
		return name;
	}
	
//	public void setName(String name) {
//		this.name = name;
//	}
	
	public void checkSpell()
	{
		spellChecker.checkSplling();
	}

}
