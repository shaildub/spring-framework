package com.capgemini.pojo.SpringLab5;

public class SpellChecker {

	public SpellChecker()
	{
		System.out.println("Inside of SpellChecker constructor.");
	}
	
	public void checkSplling()
	{
		System.out.println("Checking Spelling");
	}

}
