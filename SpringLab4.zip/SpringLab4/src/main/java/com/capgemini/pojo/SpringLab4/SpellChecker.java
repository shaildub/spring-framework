package com.capgemini.pojo.SpringLab4;

public class SpellChecker {

	public SpellChecker()
	{
		System.out.println("Inside SpellCheker Constructor....");
	}
	public void checkSpelling()
	{
		System.out.println("Inside SpellChecking");
	}

}
