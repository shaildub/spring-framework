package com.capgemini.pojo.SpringLab4;

public class TextEditor {
	
	private SpellChecker spellChecker;
	
//	with constructor
	
	public TextEditor(SpellChecker spellChecker)
	{
		System.out.println("Text Editor Constructor");
		this.spellChecker=spellChecker;
	}
	 
	public void spellCheck()
	{
		spellChecker.checkSpelling();
	}

//	with setter
	
	public SpellChecker getSpellChecker() {
		return spellChecker;
	  }

	public void setSpellChecker(SpellChecker spellChecker) {
		System.out.println("Inside setSpellChecker." );
		this.spellChecker = spellChecker;
	}
	
}
