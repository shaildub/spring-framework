package com.capgemini.pojo.OracleDataSource;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        @SuppressWarnings("resource")
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("app-config.xml");
		POJO pj = (POJO)context.getBean("task2");
		pj.TestConn();;
		
		System.out.println("\n!!! DONE !!!");
    }
}
