package com.capgemini.pojo.OracleDataSource;

public class POJO {
	
	private String schema;
	private String dbname;
	private Integer port;
	private String uname;
	private String password;
	
	public String getSchema() {
		return schema;
	}
	public void setSchema(String schema) {
		this.schema = schema;
	}
	public String getDbname() {
		return dbname;
	}
	public void setDbname(String dbname) {
		this.dbname = dbname;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public void TestConn() {
		System.out.println("\n---Testing Connection---\n");
		System.out.println("Schema name: " + schema);
		System.out.println("data base name: " + dbname);
		System.out.println("Port name: " + port);
		System.out.println("User name: " + uname);
		System.out.println("Password: " + password);
		
	}

}
