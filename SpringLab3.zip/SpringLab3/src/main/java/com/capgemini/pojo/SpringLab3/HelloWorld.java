package com.capgemini.pojo.SpringLab3;

public class HelloWorld {

	private String message;

	public void getMessage() {
		System.out.println("My Message :" + message);
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public void init(){ 
		System.out.println("Bean Initialization Here."); 
		} 
	public void destroy(){ 
		System.out.println("Bean will destroy now."); 
		}

}
