package org.capgemini.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.capgemini.dao.UserJDBC;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserLogin {

	@RequestMapping("/index")
	public ModelAndView custindex() {
		return new ModelAndView("index");
	}

	@RequestMapping("/success")
	public ModelAndView custsuccess(HttpServletRequest req, HttpServletResponse res) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("springmvc-servlet.xml");
		UserJDBC obj= (UserJDBC)context.getBean("jdbctemp");
		
		String name = req.getParameter("user");
		String pass = req.getParameter("pass");
	
		
		String submit = req.getParameter("selected");
		if(submit.equalsIgnoreCase("insert"))
		{
			obj.insert(name, pass);
			
		}
		else if(submit.equalsIgnoreCase("update"))
		{
			obj.update(name, pass);
			
		}
		else if(submit.equalsIgnoreCase("delete"))
		{
			obj.delete(name);
			
		}
		
		String a= "Task Completed";
		return new ModelAndView("success","message",a);
	}
	
}
