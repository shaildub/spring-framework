package org.capgemini.dao;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class UserJDBC  implements UserDao {
	
	 private DataSource dataSource; 
	 private JdbcTemplate jdbcTemplateObject;
	 
	 public void setDataSource(DataSource ds) {
		 this.dataSource=ds;
		 this.jdbcTemplateObject=new JdbcTemplate(dataSource);
	 }
	 
	 public void insert(String uname, String passw) {
		 String sql="insert into UserPass(uname,passw) values(?,?)";
		 jdbcTemplateObject.update(sql,uname, passw);
		 System.out.println( "\n---Record  " + uname + "  Inserted Successfully---\n" );
	 }
	 
	 public void delete(String uname) {
		 String sql="delete from UserPass where uname=?";
		 jdbcTemplateObject.update(sql, uname);
		 System.out.println("\n---Record " + uname + " Deleted successfully---\n" );
	 }
	 
	 public void update(String uname, String passw) {
		 String sql="update UserPass set passw=? where uname=?";
		 jdbcTemplateObject.update(sql,passw, uname);
		 System.out.println("\n---Record " + uname + " Updated successfully---\n" );
	 }
	 
}
