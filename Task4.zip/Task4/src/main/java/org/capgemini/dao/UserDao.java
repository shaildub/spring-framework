package org.capgemini.dao;

import javax.sql.DataSource;

public interface UserDao {

	public void setDataSource(DataSource ds);
	
	public void insert(String uname, String passw);
	
	public void delete(String uname);
	
	public void update(String uname, String passw);
	
}
