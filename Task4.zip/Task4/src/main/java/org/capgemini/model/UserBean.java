package org.capgemini.model;

public class UserBean {

	private String uname;
	private String passw;

	public String getUname() {
	return uname;
	}
	
	public void setUname(String uname) {
	this.uname = uname;
	}
	
	public String getPassw() {
	return passw;
	}
	
	public void setPassw(String passw) {
	this.passw = passw;
	}
	
	@Override
	public String toString() {
	return "Model [uname=" + uname + ", passw=" + passw + "]";
	}
	
}
