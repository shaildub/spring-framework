package org.capgemini;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@RequestMapping("/index")
	public ModelAndView custindex() {
		return new ModelAndView("index");
	}

	@RequestMapping("/display")
	public ModelAndView custsuccess(HttpServletRequest req, HttpServletResponse res) {
		String name = req.getParameter("uname");
		String dept = req.getParameter("dept");
		String msg= "Display";
		String a= name + " " + dept + " " + msg;
		return new ModelAndView("display","message",a);
	}
	
}
