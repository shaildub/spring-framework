package com.capgemini.Deprecated;

public class Testing {

//	@Profile("UAT_Testing")
//	@Deprecated
	
	@Configuration
	@Profile("Testing")
	@Deprecated
	public Integer add(Integer x, Integer y) {
		System.out.println("In Testing Add");
		Integer z = 0;
		z = x + y;
		return z;
		
	}
	
}
