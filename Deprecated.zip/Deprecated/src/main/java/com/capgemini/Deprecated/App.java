package com.capgemini.Deprecated;

public class App 
{
    public static void main( String[] args ) {
    	System.out.println("In Main");
    	
    	
    }
}
