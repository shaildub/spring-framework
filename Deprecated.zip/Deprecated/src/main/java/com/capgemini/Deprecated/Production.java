package com.capgemini.Deprecated;

public class Production {

	@Profile(tag="Production")
	public Integer adds(Integer x, Integer y) {
		System.out.println("In Production Add");
		Integer z = 0;
		z = (x + y)*2;
		return z;
		
	}
	
}
