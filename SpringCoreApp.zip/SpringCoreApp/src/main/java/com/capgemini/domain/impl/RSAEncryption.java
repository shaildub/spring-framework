package com.capgemini.domain.impl;

import com.capgemini.domain.Encryption;

//

public class RSAEncryption implements Encryption {

	public void encryptData() {
		
		System.out.println("Encrypting data using RSA Encryption");
		
	}
	
}
