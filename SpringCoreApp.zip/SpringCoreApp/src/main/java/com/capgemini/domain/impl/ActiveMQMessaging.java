package com.capgemini.domain.impl;

import com.capgemini.domain.Messaging;

// active messaging queue

public class ActiveMQMessaging implements Messaging {
	
//	if user does not have smart phone, activate SMS
//	if user is having smartphone but no sim, activate email, notify
//	if user is having smartphone with sim, activate SMS, email, notify

	public void sendMessage() {
		
		System.out.println("Sending Message via Active MQ");
	}

}
