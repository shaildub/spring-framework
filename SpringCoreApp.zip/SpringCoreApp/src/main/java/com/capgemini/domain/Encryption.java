package com.capgemini.domain;

public interface Encryption {

	public void encryptData();
}
